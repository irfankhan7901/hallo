import pandas as pd
from fastavro import writer, reader, block_reader  # , parse_schema
import glob
import os
from datetime import datetime
import pytz
from dask.distributed import Client, LocalCluster
import pkg_resources
#from pathlib import Path
import multiprocessing
from itertools import chain
import json
import math
import logging
from pandas import DataFrame
#from enum import Enum
import inspect
import sys
from typing import List, Dict #, Tuple, Sequence, Union, TypedDict, Callable
currentdir = os.path.dirname(os.path.abspath(
    inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from deltinator import utils as utils


class Deltinator(object):
    """Process two input files and creates a delta export

        Parameters
        ----------
        input_file_1 : str
            A file name or name pattern (using wildcards) including path. This is treated as 'old' file
        input_file_2 : str
            A file name or name pattern (using wildcards) including path. This is treated as 'new' file
        out_delta_file : str
            File name of the delta file including path
        json_metadata : str
            A file name of the JSON metadata file. Can be found at https://github.vodafone.com/BI-Config-Factory/pd_directives
        temp_folder : str
            A folder where DASK can store temporary files for the local DASK cluster
        hash_cache_folder : str
            The folder name where the hash file(s) should be saved. This files will be reused if the source file(s) is used again
        workers : int
            When set to any value > 0, then the count of worker nodes is forced, otherwise internal mechanism choose the count of worker
        memory_limit : str
            Memory limit per worker eg. '4G'
        cluster_type : str
            choose Dask cluster type. Default tries to dedetect if Kubernetes config exists else local. 'local' or ' kubernetes' will force a mode
        worker_image : str
            Kubernetes image for the worker pods
        worker_pod_name : str
            Name of the worker pods
        namespace : str
            Namespace of your Kubernetes pods
        pvc_list: list of dict
        -------
        no return
    """
    v_custom_log_prefix = "==========> DELTA_CALC_LOG_MSG: "

    def __init__(self, input_file_1, input_file_2, out_delta_file, out_type, temp_folder, hash_cache_folder,
                 json_metadata=None, workers=0, memory_limit='4G', worker_image="daskdev/dask:latest", worker_pod_name="dask-worker-delta",
                 cluster_type='default', namespace='default', pvc_list=[], log=None,
                 compress: bool = None,
                 interface_mode: str = None,
                 source_file_type: str = None,
                 field_delimiter: str = None,
                 newline_delimiter: str = None,
                 header: bool = None,
                 footer: bool = None,
                 columns: list = None,
                 primarykeys: dict = None):
                 
        self.input_file_2 = input_file_2
        self.input_file_1 = input_file_1
        self.out_delta_file = out_delta_file
        self.out_type = out_type
        self.temp_folder = temp_folder
        self.hash_cache_folder = hash_cache_folder
        self.json_metadata = json_metadata
        self.workers = workers
        self.memory_limit = memory_limit
        self.mode = cluster_type
        self.namespace = namespace
        self.pvc_list = pvc_list
        self.worker_image= worker_image
        self.worker_pod_name = worker_pod_name
        self.compress = compress
        self.interface_mode = interface_mode
        self.source_file_type = source_file_type
        self.field_delimiter = field_delimiter
        self.newline_delimiter = newline_delimiter
        self.header = header
        self.footer = footer
        self.columns = columns
        self.primarykeys = primarykeys
        if log:
            self.logging = log
        else:
            self.logging = logging

        dummy , file_extension = os.path.splitext(self.input_file_2)
        if((file_extension == ".csv" or file_extension == ".txt") and (self.json_metadata is None)):
            if None in (self.compress,self.interface_mode,self.source_file_type,self.field_delimiter,self.newline_delimiter,self.header,self.footer,self.columns,self.primarykeys):
                raise RuntimeError("Both JSON-metadata file and parameters missing , atleast one of them is required .")

    def set_mode(self):
        """set cluster_type as mode
        ------
        no returns
        """
        if self.mode not in ('local', 'kubernetes'):
            # Try to detect environment
            installed = [pkg.key for pkg in pkg_resources.working_set]
            if 'dask-kubernetes' in installed and os.environ.get('KUBERNETES_SERVICE_HOST', False):
                self.mode = 'kubernetes'
            else:
                self.mode = 'local'

    def get_input_file_size(self) -> float:
        """ get the total new files' size
            ------
            Returns:
            input_file_size_2
        """
        input_file_size_2 = 0
        for file in glob.glob(self.input_file_2):
            input_file_size_2 += os.path.getsize(file)
        return input_file_size_2

    def set_workers(self, input_file_size_2: float):
        """ set the number of workers depending on the new file size. Maximum is 8

            no returns
        """
        if self.workers == 0:
            self.workers = math.ceil(input_file_size_2/10e8)

        if self.mode == 'local' and self.workers > multiprocessing.cpu_count():
            self.workers = multiprocessing.cpu_count()
        # As long as we have only 8 cpu's
        if self.mode == 'kubernetes' and self.workers > 8:
            self.workers = 8

    def check_and_create_hash_cache_folder(self):
        """ create hash cache folder if it doesnt exist
            ------
            no returns        
        """
        if not os.path.isdir(self.hash_cache_folder):
            try:
                os.makedirs(self.hash_cache_folder)
            except OSError:
                if self.logging:
                    self.logging.error(
                        Deltinator.v_custom_log_prefix + 'creation of the hash cache folder ' + self.hash_cache_folder + ' failed.')
                raise RuntimeError(
                    "can not create hash cache folder" + str(self.hash_cache_folder))
            else:

                if self.logging:
                    self.logging.info(Deltinator.v_custom_log_prefix +
                                      'hash cache folder ' + self.hash_cache_folder + ' created.')

    def check_and_create_temp_folder(self):
        """ create temp folder if it doesnt exist for dask local cluster
            ------
            no returns
        """
        if not os.path.isdir(self.temp_folder):
            try:
                os.makedirs(self.temp_folder)
            except OSError:
                if self.logging:
                    self.logging.error(
                        Deltinator.v_custom_log_prefix + 'creation of the temp folder ' + self.temp_folder + ' failed.')
                raise RuntimeError(
                    "can not create temp folder" + str(self.temp_folder))
            else:
                if self.logging:
                    self.logging.info(Deltinator.v_custom_log_prefix +
                                      'temp folder ' + self.temp_folder + ' created.')

    def set_up_and_start_dask_cluster(self):
        """ Set up dask local or kubernetes cluster 
            ------
            Returns:
            clusters
        """
        if self.mode == 'local':
            # Setup Dask local cluster with temp folder for communication
            self.check_and_create_temp_folder()

            os.environ["DASK_TEMPORARY_DIRECTORY"] = self.temp_folder
            cluster = LocalCluster(n_workers=self.workers,
                                   threads_per_worker=None,
                                   processes=False,
                                   local_directory=self.temp_folder)
        else:
            # Setup Dask Kubernetes cluster
            from dask_kubernetes import KubeCluster, make_pod_spec
            from dask.distributed import as_completed
            
    #             pod_spec = make_pod_spec(image='daskdev/dask:latest',
    #                                      self.memory_limit=self.memory_limit,
    #                                      memory_request=self.memory_limit,
    #                                      cpu_limit=1,
    #                                      cpu_request=1)
    #             cluster = KubeCluster(pod_spec,
    #                                   name='delta-dask',
    #                                   namespace=namespace,
    #                                   deploy_mode='remote',
    #                                   port=33000,
    #                                   dashboard_address = ':8787')
    #             cluster = KubeCluster.from_yaml('worker-spec.yml',
    #                                     namespace=namespace,
    #                                     deploy_mode='remote',
    #                                     port=33000,
    #                                     dashboard_address = ':8787')
        # shwe: d could set earlier
            d = {
                "apiVersion": "v1",
                "kind": "Pod",
                "metadata": {"labels": {"app": "dask", 
                                        "dask.org/component": "dask-worker",}},
                "spec": {
                    "containers": [
                        {   "args": ["dask-worker", "$(DASK_SCHEDULER_ADDRESS)", 
                                    "--nthreads", "1", 
                                    "--no-dashboard", 
                                    "--memory-limit", self.memory_limit +"B", 
                                    "--death-timeout", "60"],
                            "image": self.worker_image,
                            "name": self.worker_pod_name,
                            "namespace": self.namespace,
                            "env": [{"name": "EXTRA_PIP_PACKAGES", "value": "fastavro jupyter-server-proxy --proxy http://dc-proxy-rat.net.vodafone.com:8080"}],
                            "resources": {"limits": {"cpu": "1", "memory": self.memory_limit},
                                        "requests": {"cpu": "1", "memory": self.memory_limit}},
                            "volumeMounts": []
                        }
                    ],
                    "volumes": [],
                    "restartPolicy": "Never",
                    },
                }
            for pvc in self.pvc_list:
                d['spec']['containers'][0]['volumeMounts'].append({'mountPath': pvc['mount'], 'name': pvc['pvc']})
                d['spec']['volumes'].append({'name': pvc['pvc'], 'persistentVolumeClaim': {'claimName': pvc['pvc']}})
            cluster = KubeCluster.from_dict(d, 
                                            namespace=self.namespace,
                                            deploy_mode='remote', 
                                            port=8786, 
                                            dashboard_address = ':8787')
            cluster.scale(self.workers)
        return cluster

    def parse_metadata(self):
        """ Read the JSON-metadata if input is .csv or .txt file 
            Read the soruce_metadata dictonary and generate the new JSON-metadata file if input is .csv or .txt file
            and JSON-metadata is not provided
            Read avro metadata if input is .avro file
            -------
            Returns:
            source_metadata
        """
        dummy, file_extension = os.path.splitext(self.input_file_2)
        if((file_extension == ".csv" or file_extension == ".txt") and (self.json_metadata is None)):
            source_metadata = {"field delimiter": self.field_delimiter,
                                         "compressed": self.compress,
                                         "interface mode": self.interface_mode,
                                         "source file type": self.source_file_type,
                                         "newline delimiter": self.newline_delimiter,
                                         "header": str(self.header),
                                         "footer": str(self.footer),
                                         "column": self.columns,
                                         "primary key": self.primarykeys,
                                         "avro_fields": None
                                         }
            with open('new_meta_data.json', "w") as outputfile:
                json.dump(source_metadata, outputfile)
            self.json_metadata = os.path.join( os.getcwd(), 'new_meta_data.json') 

        if self.json_metadata:
            with open(self.json_metadata) as input_json:
                source_metadata = json.load(input_json)
        elif file_extension == '.avro':
            filelist = glob.glob(self.input_file_2)
            with open(filelist[0],  'rb') as input_avro:
                # with open(self.json_metadata) as input_avro:
                avro_reader = reader(input_avro)
                schema = avro_reader.writer_schema
                if 'meta-data-file' in schema:
                    source_metadata = schema['meta-data-file']
                else:
                    raise RuntimeError(
                        "unsupported avro file. meta data missing in avro header 'meta-data-file'")
        else:
            raise RuntimeError("all input files except avro need metadata")
        return source_metadata

    def process_metadata_and_find_primary_key(self, source_metadata):
        """ Get list of columns' name, dtype, and fieldwidth from the metadata
            and build avro fields list with every column type as string  

            Retuns:
            ------------
            col_list: list of columns in the input file 
            dtype: dict of column datatypes with column name as keys
            fieldwidths: list of fieldwidths for inputs of FIXED field/column width 
            avro_fields: list of dict with column name as keys and datatype string as values  
        """
        col_list = []
        dtype = {}
        fieldwidths = []
        avro_fields = []
        if 'fields' in source_metadata:
            column_field = 'fields'
        else:
            column_field = 'column'
        for _, column in enumerate(source_metadata[column_field]):
            col_list.append(column['name'])
            dtype[column['name']] = 'string'
            fieldwidths.append(column['fixed field length'])
            # column['conformed data type']
            avro_fields.append({'name': column['name'], 'type': 'string'})
        return col_list, dtype, fieldwidths, avro_fields

    def create_hashfile(self, filename: str):
        """ Create hashfile if it doesn't already exists

            Parameters:
            ------------
            filename: Input file to be hashed 


            Returns:
            ------------
            hash_filename: name of the hash file created 
        """
        hash_filename = os.path.join(self.hash_cache_folder ,os.path.basename(filename) + '.hash')
        if not os.path.isfile(hash_filename):
            dummy, file_extension = os.path.splitext(filename)

            if file_extension == '.avro':
                utils.create_hashfile_for_avro(filename, hash_filename)
            else:
                utils.create_hashfile_for_others(filename, hash_filename)

        return hash_filename

    def create_hash(self, client):
        """Create hashes for each line in a given file or file pattern. The hash file(s) will be stored
        in the hash folder. When given a file pattern, for each of the files will be a separate hash file
        created. The hash filename has the file extension .hash

        Parameters
        ----------
        filelist : list of str
            A list with file names or name patterns (using wildcards) including path
        hashfolder : str
            The folder name where the hash file(s) should be saved

        Returns
        -------
        results : list 
            a filename list of the processed files
        """

        filelist = [self.input_file_1, self.input_file_2]
        all_futures = {}
        priority = 100
        for filename in filelist:
            files = glob.glob(filename)
            files.sort()
            futures = [client.submit(
                self.create_hashfile, file, priority=priority-id) for id, file in enumerate(files)]
            priority -= (len(files) + 1)

            all_futures[filename] = futures
        # results = [future.result()
        #           for future in futures for futures in all_futures]
        results = [client.gather(futures) for futures in all_futures]
        return results

    def read_hashfile(self, filelist, startbyte=0, modulo=1, blocksize=10000):
        """Read all hashfiles from a given filelist with the option to filter on the first byte   
        Parameters
        ----------
        filelist : str
            Filename list of the input files. The hash files of these files must exists in the hash folder.
        startbyte : int
            Start byte to filter on. It must be smaller the modulo value. If you eg. call modulo 8 and call startbyte 2, 
            the reader will load all hash starting with 2, 10, 18, 26,..., 250.
        modulo : int
            The modulo value for the filter. If you eg. call modulo 8 every 8th byte value will be read

        Returns
        -------
        list_hash : list
            All indexes (rownums) from file_1 which don't exists in file_1
        hash_position
            All indexes (rownums) from file_2 which don't exists in file_2
        file_windows
            If a file name pattern is given, the windows1 will have a list of dict with start row and end row of each file 
            eg. [{'start':0,'end':99}, {'start':100,'end':199},...]

        """
        if startbyte > modulo:
            raise RuntimeError(
                "startbyte(" + str(startbyte) + ") must be below modulo (" + str(modulo) + ") parameter")
        list_hash = []
        hash_position = []
        file_windows = []
        filelist = glob.glob(filelist)
        filelist.sort()
        if len(filelist) == 0:
            raise RuntimeError("Input file(s) " +
                               str(filelist) + " not found")
        pos = 0
        for id, file in enumerate(filelist):
            startpos = pos
            filepath = os.path.join(self.hash_cache_folder, os.path.basename(file) + '.hash' )
            with open(filepath, 'rb') as hash_file:
                while(hash_block := hash_file.read(28 * blocksize)):
                    if blocksize == 1:
                        # shwe: test and render obsolete
                        if (hash_block[0] % modulo) == startbyte:
                            list_hash.append(hash_block)
                        pos += 1
                    else:
                        for i in range(0, len(hash_block), 28):
                            if (hash_block[i] % modulo) == startbyte:
                                list_hash.append(hash_block[i:i+28])
                                hash_position.append(pos)
                            pos += 1

            file_windows.append({'start': startpos, 'end': pos - 1})
        return list_hash, hash_position, file_windows

    # @staticmethod
    # def difference(list1, list1_pos, list2):
    #     temp = set(list2)
    #     return [list1_pos[i] for i, h in enumerate(list1) if h not in temp]

    def difference_process(self, process, parallel):
        """
        Read the hash file and find the difference between the input hashfile files
        Parameters
        ----------
        process: int
             number of the current process
        parallel: int
             Count of parallel Dask processes

        Returns
        ---------
        list1_index : list
        list2_index :  list
        list1_windows : list
        list2_windows : list
        """
        list1_hash, list1_pos, list1_windows = self.read_hashfile(
            self.input_file_1, process, parallel)
        list2_hash, list2_pos, list2_windows = self.read_hashfile(
            self.input_file_2, process, parallel)

        list1_index = utils.difference(list1_hash, list1_pos, list2_hash)
        list2_index = utils.difference(list2_hash, list2_pos, list1_hash)

        return list1_index, list2_index, list1_windows, list2_windows

    def find_difference(self, parallel, client):
        """Find differences 

        Parameters
        ----------
        file_1 : list of str
            A file name or name pattern (using wildcards) including path. 
            The function will check for the hash files in the hash folder.
        file_2 : list of str
            A file name or name pattern (using wildcards) including path.
            The function will check for the hash files in the hash folder.
        parallel : int
            Count of parallel Dask processes

        Returns
        -------
        list1_index : list
            All indexes (rownums) from file_1 which don't exists in file_1
        list2_index
            All indexes (rownums) from file_2 which don't exists in file_2
        windows1
            If a file name pattern is given, the windows1 will have a list of dict with start row and end row of each file 
            eg. [{'start':0,'end':99}, {'start':100,'end':199},...]
        windows2
            If a file name pattern is given, the windows2 will have a list of dict with start row and end row of each file
        """
        hashlist_futures = [client.submit(self.difference_process, process, parallel, priority=parallel-process)
                            for process in range(parallel)]

        list1_index = []
        list2_index = []
        # Shwe: saves 0.04 seconds fo 4KB input file : test for bigger file
        results = client.gather(hashlist_futures)
        results_df = pd.DataFrame(
            results, columns=['l1_index', 'l2_index', 'l1_windows', 'l2_windows'])
        list1_index = list(chain.from_iterable(
            results_df['l1_index'].values))
        list2_index = list(chain.from_iterable(
            results_df['l2_index'].values))
        windows1 = results_df.iloc[0, 2]
        windows2 = results_df.iloc[0, 3]
        # for id, future in enumerate(hashlist_futures):
        #     l1_index, l2_index, l1_windows, l2_windows = future.result()
        #     list1_index.extend(l1_index)
        #     list2_index.extend(l2_index)
        #     windows1 = l1_windows
        #     windows2 = l2_windows

        list1_index.sort()
        list2_index.sort()

        return list1_index, list2_index, windows1, windows2

    def read_file(self, filename: str, load_list: list, source_metadata, fieldwidths: list, blocksize=int(100e6)) -> list:
        """ Read input file
        Parameters:
        -----------
        filename:
                input file
        load_list: 
                indices of records that changed
        source_metadata:
                metadata
        fieldwidths:
                list of fieldwidths for inputs of FIXED field/column width
        Returns:
        --------------
        list_records:
                records that have changed
        """
        starttime = datetime.now()
        list_records = []
        start_pos = 0
        dummy, file_extension = os.path.splitext(filename)
        if file_extension == '.avro':
            with open(filename, 'rb') as source_file:
                avro_reader = block_reader(source_file)
#                         list_records = [record.values() for i, record in enumerate(avro_reader) if i in load_list]

                list_records = []
                for block in avro_reader:
                    load_part = utils.get_window(
                        load_list, start_pos, start_pos + block.num_records - 1)
                    for i, record in enumerate(block):
                        if i in load_part:
                            list_records.append(record.values())
                    start_pos = start_pos + block.num_records
                if self.logging:
                    self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) + ': finished file' + filename + ' with ' +
                                      str(len(list_records)) + 'records after ' + str(datetime.now() - starttime))
        else:
            with open(filename, 'r') as source_file:
                list_part = source_file.readlines(blocksize)
                while len(list_part) != 0:
                    load_part = utils.get_window(
                        load_list, start_pos, start_pos + len(list_part) - 1)

                    if 'field delimiter' in source_metadata:
                        t = [utils.parse_delimited(
                            list_part[index], source_metadata['field delimiter']) for index in load_part]
                    else:
                        t = [utils.parse_fixed_column_size(
                            list_part[index], fieldwidths) for index in load_part]
                    list_records.extend(t)
                    start_pos = start_pos + len(list_part)
                    list_part = source_file.readlines(blocksize)
        return list_records

    def read_records(self, filename, windows, loadlist, source_metadata, fieldwidths, col_list, client, blocksize=int(100e6)) -> DataFrame:
        """ Read input files and load delta to dataframe

            Parameters:
            ------------------
            filename: str
                    input_file
            windows: dict
                    file window 
            loadlist: list of hash indices with change
            source_metadata:
                    json or avro metadata
            fieldwidths: list
                    fixed column widths
            col_list: list 
                    columns in the input file
            client: Dask client

            Returns:
            -----------------
            df
        """
        starttime = datetime.now()
        filelist = glob.glob(filename)
        filelist.sort()
        futures = [client.submit(self.read_file,
                                 file,
                                 utils.get_window_list(
                                     id, loadlist, windows),
                                 source_metadata,
                                 fieldwidths,
                                 blocksize
                                 ) for id, file in enumerate(filelist)]
       # list_parts = [future.result() for future in futures]
        list_parts = client.gather(futures)
#             list_parts = []
#             for id, file in enumerate(filelist):
#                 part = read_file(file, get_window_list(id, loadlist, windows), blocksize)
#                 list_parts.append(part)
        flat_list = [item for sublist in list_parts for item in sublist]
        df = pd.DataFrame(flat_list, columns=col_list)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) + ': Load delta from file ' +
                              filename + ' (' + str(datetime.now() - starttime) + ')')

        return df
 
    def update_and_dump_source_metadata(self, source_metadata):
        """ Add field delimiter to the metadata if output type is csv 
            Dump the updated metadata to a json file with same name as the output delta file

            Parameters:
            --------------
            source_metadata: dict
                metadata


            Returns:
            -------------
            source_metadata: dict 
                updated source metadata
        """
        # shwe: could be set earlier
        delta_meta = {'name': 'RCI', 'nullable': False, 'db data type': 'CHAR(1)', 'conformed data type': 'string',
                      'fixed field length combined': 1, 'fixed field length': 1, 'format': '',
                      'description': 'Delta column', 'comment': 'I=Insert, U=Update, D=Delete', 'primary': False,
                      'foreign key': False, 'transformation': None, 'mapping': []}
        if 'fields' in source_metadata:
            column_field = 'fields'
        else:
            column_field = 'column'
        source_metadata[column_field].append(delta_meta)
        if self.out_type == 'CSV':
            source_metadata['field delimiter'] = '~|~'

        with open(self.out_delta_file + '.meta.json', 'w') as meta_file:
            json.dump(source_metadata, meta_file)
        return source_metadata

    def export_delta_file(self, df_delta,  avro_fields, fieldwidths, source_metadata):
        """ Export the delta file 
            Parameters: 
            ------------
            df_delta- dataframe with delta entries
            avro_fields- column list with dtype string
            fieldwidths- fieldwidths of columns in the input file with FIXED format Ex: text file
            source_metadata- metadata from json file or avro schema 

            Returns:
            ---------

        """
        if self.out_type == 'JSON':
            # Exporting delta file as JSON
            self.export_json_delta_file(df_delta)
        elif self.out_type == 'AVRO':
            # Build avro-schema
            self.export_avro_delta_file(
                df_delta,  avro_fields, fieldwidths, source_metadata)
        elif self.out_type == 'CSV':
            # Exporting delta file as CSV with ~|~ seperator
            self.export_csv_delta_file(df_delta)

    def export_json_delta_file(self, df_delta: DataFrame):
        """ Exporting delta file as JSON
            -----------
            Parameters:
            df_delta- dataframe with delta entries

            Returns:
            -----

        """

        starttime = datetime.now()
        df_delta.reset_index(drop=True, inplace=True)
        df_delta.to_json(self.out_delta_file, orient='records')
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Export JSON. (' + str(datetime.now() - starttime) + ')')

    def export_avro_delta_file(self, df_delta: DataFrame, avro_fields: Dict, fieldwidths: List, source_metadata):
        """ Exporting delta file as Avro by building the schema
            Parameters:
            -----------
            df_delta:
            avro_fields
            source_metadata

            Returns:
            ----------

        """
        starttime = datetime.now()
        avro_fields.append({'name': 'PK', 'type': 'string'})
        avro_fields.append({'name': 'RCI', 'type': 'string'})
        schema = {'name': 'Deltafile',
                  'type': 'record',
                  'source-file': self.input_file_2,
                  'batch-id': 1,
                  'partition-number': 0,
                  'meta-data-file': source_metadata,
                  'meta-data': self.json_metadata,
                  # 2=Deltafile generator, 3=Data cleansing, 4=Data transformation, 5=Encrypted GCP output
                  'process-step': 2,
                  'timestamp': datetime.now(pytz.timezone('Europe/Berlin')).isoformat(),
                  'delta-count': len(df_delta),
                  'fields': avro_fields
                  }

        with open(self.out_delta_file, 'wb') as out:
            writer(out, schema, df_delta.astype(
                str).to_dict(orient='records'))
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Export AVRO. (' + str(datetime.now() - starttime) + ')')

    def export_csv_delta_file(self, df_delta: DataFrame):
        """ Exporting delta file as CSV with ~|~ seperator
            Parameters:
            -----------
            df_delta


            Returns:
            ----------
        """
        starttime = datetime.now()
        df_delta.agg('~|~'.join, axis=1).to_csv(
            self.out_delta_file, index=False, header=False)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Export AVRO. (' + str(datetime.now() - starttime) + ')')

    def start_process(self):
        """start the deltinator process

            Parameters:
            -----------

            Returns:
            ----------
        """
        total_starttime = datetime.now()

        self.set_mode()
        input_file_size_2 = self.get_input_file_size()
        self.set_workers(input_file_size_2)
        self.check_and_create_hash_cache_folder()
        cluster = self.set_up_and_start_dask_cluster()

        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix +
                              'file previous day: ' + self.input_file_1)
            self.logging.info(Deltinator.v_custom_log_prefix + 'file today: ' +
                              self.input_file_2 + ' (filesize ' + str(input_file_size_2) + ')')
            self.logging.info(Deltinator.v_custom_log_prefix +
                              'out file: ' + self.out_delta_file)
            self.logging.info(Deltinator.v_custom_log_prefix +
                              'json_metadata: ' + str(self.json_metadata))
            self.logging.info(Deltinator.v_custom_log_prefix +
                              'self.mode: ' + self.mode)
            self.logging.info(Deltinator.v_custom_log_prefix +
                              'self.workers: ' + str(self.workers))
            self.logging.info(
                Deltinator.v_custom_log_prefix + str(cluster))

        client = Client(cluster)
        
        source_metadata = self.parse_metadata()

        col_list, dtype, fieldwidths, avro_fields = self.process_metadata_and_find_primary_key(
            source_metadata)

        starttime = datetime.now()
        self.create_hash(client)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()
                                                                   ) + ': create hash (' + str(datetime.now() - starttime) + ')')

        starttime = datetime.now()
        old, new, old_windows, new_windows = self.find_difference(8, client)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': find diff (' + str(datetime.now() - starttime) + ')')

        df_old = self.read_records(
            self.input_file_1, old_windows, old, source_metadata, fieldwidths, col_list, client)
        df_new = self.read_records(
            self.input_file_2, new_windows, new, source_metadata, fieldwidths, col_list, client)

        starttime = datetime.now()
        utils.set_pk(df_old, source_metadata['primary key']['columns'])
        utils.set_pk(df_new, source_metadata['primary key']['columns'])
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Building primary key finished. (' + str(datetime.now() - starttime) + ')')

        starttime = datetime.now()
        df_insert, new_hash = utils.find_inserts(df_old, df_new)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) + ': Found ' +
                              str(len(df_insert)) + ' inserts. (' + str(datetime.now() - starttime) + ')')

        starttime = datetime.now()
        df_delete, old_hash = utils.find_deletes(df_old, df_new)
        # Finding Deletes
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) + ': Found ' +
                              str(len(df_delete)) + ' deletes. (' + str(datetime.now() - starttime) + ')')

        starttime = datetime.now()
        df_update = utils.find_updates(df_new, old_hash, new_hash)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) + ': Found ' +
                              str(len(df_update)) + ' updates. (' + str(datetime.now() - starttime) + ')')

        starttime = datetime.now()
        df_delta = utils.create_insert_update_delete_dataframe(
            df_insert, df_delete, df_update)
        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Building final DataFrame. (' + str(datetime.now() - starttime) + ')')

        source_metadata = self.update_and_dump_source_metadata(source_metadata)
        self.export_delta_file(df_delta,  avro_fields,
                               fieldwidths, source_metadata)

        if self.logging:
            self.logging.info(Deltinator.v_custom_log_prefix + str(datetime.now()) +
                              ': Total runtime. (' + str(datetime.now() - total_starttime) + ')')

        client.close()
        cluster.close()





   
