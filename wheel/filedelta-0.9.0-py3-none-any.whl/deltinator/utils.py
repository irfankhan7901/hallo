import pandas as pd
import hashlib
import struct
from fastavro import  reader #, writer, block_reader , parse_schema
#from datetime import datetime, timezone
import bisect
#from dask.distributed import Client, LocalCluster
#from pathlib import Path
#from itertools import chain


def create_hashfile_for_avro(filename, hash_filename):
    """ Create hashfile for avro input
    Parameters:
    -----------
    filename: str
            input file
    hash_filename: str
            hash file name 
    Returns:
    ----------
    
    """
    with open(filename, 'rb') as source_file:
        with open(hash_filename, 'wb') as hash_file:
            avro_reader = reader(source_file)
            [hash_file.write(hashlib.sha224('|'.join(line.values()).encode(
                'utf-8')).digest()) for line in avro_reader]


def create_hashfile_for_others(filename, hash_filename):
    """ Create hashfile for txt or csv input
    Parameters:
    -----------
    filename: str
            input file
    hash_filename: str
            hash file name 

    Returns:
    ----------
    """
    with open(filename, 'r') as source_file:
        with open(hash_filename, 'wb') as hash_file:
            [hash_file.write(hashlib.sha224(line.encode(
                'utf-8')).digest()) for line in source_file]


def difference(list1, list1_pos, list2):
    temp = set(list2)
    return [list1_pos[i] for i, h in enumerate(list1) if h not in temp]


def parse_fixed_column_size(line, fieldwidths):
    fieldstruct = struct.Struct(' '.join('{}{}'.format(
        abs(fw), 'x' if fw < 0 else 's') for fw in fieldwidths))
    return tuple(s.decode().rstrip() for s in fieldstruct.unpack_from(line.encode()))


def parse_delimited(line, delimiter):
    return line.split(delimiter)


def get_window_list(index, list, windows):
    lower_border = windows[index]['start']
    upper_border = windows[index]['end']
    return get_window(list, lower_border, upper_border)


def get_window(list, lower_border, upper_border):
    lower_index = bisect.bisect_left(list, lower_border)
    upper_index = bisect.bisect_right(list, upper_border)
    temp = [x - lower_border for x in list[lower_index:upper_index]]
    return temp


def set_pk(df, primarykey):
    df['PK'] = df[primarykey] \
        .astype(str) \
        .sum(axis=1)


def find_inserts(df_old, df_new):
    # Finding Inserts

    new_hash = set(df_new['PK'])
    new_hash.difference_update(set(df_old['PK']))
    df_insert = df_new[df_new['PK'].isin(new_hash)]
    df_insert.insert(len(df_insert.columns), 'RCI', 'I')

    return df_insert, new_hash


def find_deletes(df_old, df_new):
    # Finding Deletes

    old_hash = set(df_old['PK'])
    old_hash.difference_update(set(df_new['PK']))
    df_delete = df_old[df_old['PK'].isin(old_hash)]
    df_delete.insert(len(df_delete.columns), 'RCI', 'D')

    return df_delete, old_hash


def find_updates(df_new, old_hash, new_hash):
    # Finding Updates

    update_hash = set(df_new['PK'])
    update_hash.difference_update(new_hash.union(old_hash))
    df_update = df_new[df_new['PK'].isin(update_hash)]
    df_update.insert(len(df_update.columns), 'RCI', 'U')

    return df_update


def create_insert_update_delete_dataframe(df_insert, df_update, df_delete):
    # Building DataFrame with all inserts, updates and deletes

    df_delta = pd.concat([df_insert, df_update, df_delete])

    return df_delta
